const TelegramBot = require('node-telegram-bot-api');
const token = process.env.TELEGRAM_BOT_TOKEN;
const bot = new TelegramBot(token, { polling: true });

bot.on('message', (msg) => {
  const chatId = msg.chat.id;
  if (msg.text.toLowerCase() === 'hi') {
    bot.sendMessage(chatId, 'Chào bạn! Tôi có thể giúp gì cho bạn?');
  }
});
